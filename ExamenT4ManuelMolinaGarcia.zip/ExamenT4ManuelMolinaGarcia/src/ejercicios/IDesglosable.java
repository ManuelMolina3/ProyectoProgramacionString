package ejercicios;

public interface IDesglosable {
 
	double calcularIva (double porcentajeIva, double precio1, double precio2);
}
