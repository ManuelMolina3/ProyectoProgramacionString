package ejercicio4;

public interface IImprimirPaplinas {
	void imprimirCod();
}
