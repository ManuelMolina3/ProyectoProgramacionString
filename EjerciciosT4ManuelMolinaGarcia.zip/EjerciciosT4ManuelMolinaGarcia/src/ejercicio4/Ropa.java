package ejercicio4;

public class Ropa extends Producto{

	public Ropa(double precioUni, String nombre, String id) {
		super(precioUni, nombre, id);
		// TODO Auto-generated constructor stub
	}
	public double calcularPrecioUni () {
		return super.calcularPrecioUni();
	}
}
