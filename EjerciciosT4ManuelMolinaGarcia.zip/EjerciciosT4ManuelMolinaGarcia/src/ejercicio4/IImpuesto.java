package ejercicio4;

public interface IImpuesto {
	double calcularIVA(double procentaje);
	
}
