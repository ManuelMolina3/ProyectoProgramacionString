package ejemploInterfaces;

public interface IPresa {
	void huir();
}
