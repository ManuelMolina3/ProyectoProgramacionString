package ejemploInterfaces;

public interface IDepredador {
	
	//Se pasa un animal por el ejemplo no es necesario pasar un objeto de la clase wque implementan
	void localizar ();
	void cazar ();	
}
