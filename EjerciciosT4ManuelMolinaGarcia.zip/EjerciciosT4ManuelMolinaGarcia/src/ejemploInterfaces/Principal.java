package ejemploInterfaces;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a= new Animal("Negro", 2);
		
		a.cazar();
	}

}
