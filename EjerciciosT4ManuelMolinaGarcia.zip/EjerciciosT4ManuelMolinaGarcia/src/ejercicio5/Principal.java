package ejercicio5;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Crear una clase Empleado con los atributos nombre, apellidos, sueldo base y nº de Empleado.
		Introducir los métodos necesarios y oportunos.
		Crear una clase derivada de ella, llamada Vendedor que tenga como atributos la cantidad de ventas y
		un incentivo (un porcentaje de las ventas realizadas en un mes sumado a su sueldo base) y los métodos
		apropiados para manejarla.
		Otra clase hija puede ser Gerente, cuyo sueldo es el base, pero al que se le quita un % de impuestos
		(consideraremos que al vendedor no se le quita nada para que el ejercicio tenga algo más de sentido).
		Crear una clase Oficina caracterizada por una lista de Empleados donde se incluya un método que
		calcule el sueldo de un empleado pasándole como parámetro un empleado y otro método que calcule
		lo gastado por la oficina en total por el pago de sueldos a todos los empleados.
		Probar el programa en una clase principal, instanciando un array de empleados guardando varios tipos
		incluyendo un empleado genérico y mostrando su sueldo. Si el empleado es un vendedor se le debe
		felicitar con un mensaje por pantalla cuando haya vendido más de una cantidad pasada como parámetro
		que será su objetivo de ventas.*/
		
	}

}
